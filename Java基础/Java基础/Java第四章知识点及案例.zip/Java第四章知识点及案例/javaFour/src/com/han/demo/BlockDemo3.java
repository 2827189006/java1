package com.han.demo;
/**
 * 
 * @authork ��������
 *
 */
public class BlockDemo3 {
	
public static void main(String[] args) {
	
	{
		int bookPrice=23;
		System.out.println("bookPrice="+bookPrice);
	}
	int bookPrice=20;	
	System.out.println("bookPrice="+bookPrice);		
}
}
